import torch
import torchvision
import torchvision.transforms as transforms
from torchvision import models
import toml
import json
from itertools import product
import torch.nn as nn
import torch.optim as optim
import warnings

warnings.filterwarnings("ignore")

with open("config.json") as f:
    config = json.load(f)

params = toml.load("params.toml")
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.RandomHorizontalFlip(),
    transforms.ToTensor(),
    transforms.Normalize((0.5,), (0.5,))
])

trainset_full = torchvision.datasets.CIFAR10(root="./data", train=True, download=True, transform=transform)
train_subset = torch.utils.data.Subset(trainset_full, range(config["training"]["mini_train_samples"]))
trainloader = torch.utils.data.DataLoader(train_subset, batch_size=config["training"]["batch_size"], shuffle=True)

testset = torchvision.datasets.CIFAR10(root="./data", train=False, download=True, transform=transform)
testloader = torch.utils.data.DataLoader(testset, batch_size=config["demo"]["num_samples"], shuffle=True)
classes = testset.classes

lr = params["training"]["learning_rate"]
momentum = params["training"]["momentum"]
optimizer_type = params["training"]["optimizer"]

for arch in config["model"]["architectures"]:
    print(f"\n====================\n{arch}\n====================\n")
    
    model_class = getattr(models, arch)
    model = model_class(weights=models.get_model_weights(arch).DEFAULT)
    model.fc = nn.Linear(model.fc.in_features, config["model"]["num_classes"])
    model = model.to(device)
    
    for param in model.parameters():
        param.requires_grad = False
    for param in model.fc.parameters():
        param.requires_grad = True
    
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.SGD(model.fc.parameters(), lr=lr, momentum=momentum) if optimizer_type.lower()=="sgd" else optim.Adam(model.fc.parameters(), lr=lr)
    
    model.train()
    for epoch in range(config["training"]["epochs"]):
        running_loss = 0.0
        for inputs, labels in trainloader:
            inputs, labels = inputs.to(device), labels.to(device)
            optimizer.zero_grad()
            outputs = model(inputs)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()
            running_loss += loss.item()
        print(f"[{arch}] Epoch {epoch+1} Loss: {running_loss/len(trainloader):.4f}")
    
    model.eval()
    dataiter = iter(testloader)
    images, labels = next(dataiter)
    images, labels = images.to(device), labels.to(device)
    
    with torch.no_grad():
        outputs = model(images)
        _, predicted = torch.max(outputs, 1)
    
    print(f"\nPredictions for {arch}:")
    for i in range(config["demo"]["num_samples"]):
        true_label = classes[labels[i].item()]
        pred_label = classes[predicted[i].item()]
        print(f"Image {i+1}: True → {true_label}, Predicted → {pred_label}")

print("\nGrid Search Hyperparameters:")
for lr_val, opt, m in product(config["grid_search"]["learning_rates"],
                              config["grid_search"]["optimizers"],
                              config["grid_search"]["momentum"]):
    print(f"LR={lr_val}, Optimizer={opt}, Momentum={m}")

print("\nPipeline completed successfully.")
